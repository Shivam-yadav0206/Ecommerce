(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[next]_internal_font_google_poppins_4e3dc702_module_9e9ca05e.css",
  "static/chunks/node_modules_0a054fc5._.js",
  "static/chunks/src_78e31f27._.js"
],
    source: "dynamic"
});
