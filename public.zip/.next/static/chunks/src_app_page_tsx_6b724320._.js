(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_ea17edbd._.js",
  "static/chunks/node_modules_next_8d365768._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_axios_lib_99999129._.js",
  "static/chunks/node_modules_react-slick_lib_4ed59f97._.js",
  "static/chunks/node_modules_3ee65a11._.js"
],
    source: "dynamic"
});
